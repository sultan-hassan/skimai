# SkimAI - Minimal Next.js Starter

This is a minimal Next.js app to demonstrate a simple summary generation API.

## Scripts

- `npm run dev` - start dev server
- `npm run build` - build app
- `npm run start` - start production server

## Usage

- Click the "Generate Summary" button on homepage to call the API route.